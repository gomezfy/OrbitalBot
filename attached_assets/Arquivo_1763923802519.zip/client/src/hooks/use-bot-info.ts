import { useQuery } from "@tanstack/react-query";

interface BotInfo {
  id: string;
  username: string;
  discriminator: string;
  avatar: string;
  inviteUrl?: string;
}

export function useBotInfo() {
  return useQuery<BotInfo>({
    queryKey: ["/api/bot/info"],
    queryFn: async () => {
      const response = await fetch("/api/bot/info");
      if (!response.ok) {
        throw new Error("Erro ao buscar informações do bot");
      }
      return response.json();
    },
    staleTime: 5 * 60 * 1000,
    retry: 2,
  });
}
