import type { User } from "@shared/schema";

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "ApiError";
  }
}

async function fetchApi<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
    credentials: "include",
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: "Erro desconhecido" }));
    throw new ApiError(response.status, error.message || response.statusText);
  }

  return response.json();
}

export const authApi = {
  login: (username: string, password: string) =>
    fetchApi<User>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }),

  register: (username: string, password: string) =>
    fetchApi<User>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }),

  logout: () =>
    fetchApi<{ message: string }>("/api/auth/logout", {
      method: "POST",
    }),

  me: () => fetchApi<User>("/api/auth/me"),

  discordLogin: async () => {
    const response = await fetch("/api/auth/discord");
    const data = await response.json();
    
    if (!response.ok) {
      throw new ApiError(response.status, data.message || "Erro ao conectar com Discord");
    }
    
    if (!data.authUrl) {
      throw new ApiError(500, "URL de autenticação não disponível. Verifique se o DISCORD_CLIENT_ID está configurado.");
    }
    
    return data.authUrl;
  },
};

export const statsApi = {
  get: () => fetchApi("/api/stats"),
  update: (stats: any) =>
    fetchApi("/api/stats", {
      method: "PUT",
      body: JSON.stringify(stats),
    }),
};

export const settingsApi = {
  get: () => fetchApi("/api/settings"),
  update: (settings: any) =>
    fetchApi("/api/settings", {
      method: "PATCH",
      body: JSON.stringify(settings),
    }),
};

export const activityApi = {
  get: () => fetchApi("/api/activity"),
};

export const guildsApi = {
  get: () => fetchApi("/api/guilds"),
};
