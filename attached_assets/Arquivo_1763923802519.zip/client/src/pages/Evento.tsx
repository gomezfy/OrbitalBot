import { motion, AnimatePresence } from "framer-motion";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Trophy, Timer, Zap, Target, Medal, TrendingUp, Flame, Crown, Sparkles, Pickaxe, Coins } from "lucide-react";
import { useState } from "react";

interface EventData {
  name: string;
  active: boolean;
  phase: number;
  timeRemaining: string;
  nextDate: string;
}

interface LeaderboardEntry {
  rank: number;
  username: string;
  points: number;
  medal?: string;
}

interface PrizeEntry {
  position: number;
  silver: number;
  tokens: number;
  xp: number;
  medal: string;
}

const spring = { type: "spring", stiffness: 100, damping: 15, mass: 1 } as const;
const springFast = { type: "spring", stiffness: 300, damping: 30, mass: 0.8 } as const;

export default function Evento() {
  const heroBg = "/assets/images/western_landscape_hero_background.png";
  
  // Event Data - Corrida do Ouro
  const miningEvent: EventData = {
    name: "Corrida do Ouro",
    active: true,
    phase: 3,
    timeRemaining: "2d 14h 32m",
    nextDate: "Próximo domingo"
  };

  // Event Data - Caçada do Xerife
  const huntingEvent: EventData = {
    name: "Caçada do Xerife",
    active: false,
    phase: 0,
    timeRemaining: "",
    nextDate: "Em breve"
  };

  // Leaderboard - Top 10 Miners
  const mockLeaderboard: LeaderboardEntry[] = [
    { rank: 1, username: "CowboyMaster", points: 45230, medal: "🥇" },
    { rank: 2, username: "GoldDigger", points: 38120, medal: "🥈" },
    { rank: 3, username: "WesternKing", points: 32450, medal: "🥉" },
    { rank: 4, username: "SheriffFan", points: 28900, medal: "4º" },
    { rank: 5, username: "MinerPro", points: 25600, medal: "5º" },
    { rank: 6, username: "DustTrail", points: 22340, medal: "6º" },
    { rank: 7, username: "GoldenHeart", points: 19800, medal: "7º" },
    { rank: 8, username: "LuckyShot", points: 16500, medal: "8º" },
    { rank: 9, username: "WildWest", points: 14200, medal: "9º" },
    { rank: 10, username: "DesertRose", points: 11900, medal: "10º" },
  ];

  // Prize Structure - Corrida do Ouro
  const miningPrizes: PrizeEntry[] = [
    { position: 1, silver: 300000, tokens: 300, xp: 3500, medal: "🥇" },
    { position: 2, silver: 200000, tokens: 200, xp: 1750, medal: "🥈" },
    { position: 3, silver: 100000, tokens: 100, xp: 875, medal: "🥉" },
    { position: 4, silver: 50000, tokens: 50, xp: 400, medal: "4º" },
    { position: 5, silver: 40000, tokens: 40, xp: 350, medal: "5º" },
    { position: 6, silver: 30000, tokens: 30, xp: 300, medal: "6º" },
    { position: 7, silver: 20000, tokens: 20, xp: 250, medal: "7º" },
    { position: 8, silver: 15000, tokens: 15, xp: 200, medal: "8º" },
    { position: 9, silver: 10000, tokens: 10, xp: 150, medal: "9º" },
    { position: 10, silver: 5000, tokens: 5, xp: 100, medal: "10º" },
  ];

  // Prize Structure - Caçada do Xerife
  const huntingPrizes: PrizeEntry[] = [
    { position: 1, silver: 500000, tokens: 500, xp: 5000, medal: "🥇" },
    { position: 2, silver: 350000, tokens: 350, xp: 3000, medal: "🥈" },
    { position: 3, silver: 200000, tokens: 200, xp: 1500, medal: "🥉" },
    { position: 4, silver: 100000, tokens: 100, xp: 750, medal: "4º" },
    { position: 5, silver: 80000, tokens: 80, xp: 600, medal: "5º" },
    { position: 6, silver: 60000, tokens: 60, xp: 500, medal: "6º" },
    { position: 7, silver: 40000, tokens: 40, xp: 400, medal: "7º" },
    { position: 8, silver: 30000, tokens: 30, xp: 300, medal: "8º" },
    { position: 9, silver: 20000, tokens: 20, xp: 200, medal: "9º" },
    { position: 10, silver: 10000, tokens: 10, xp: 100, medal: "10º" },
  ];

  const [activeTab, setActiveTab] = useState<"overview" | "ranking" | "prizes">("overview");
  const [selectedEvent, setSelectedEvent] = useState<"mining" | "hunting">("mining");

  // Helper to get medal icon and color based on position
  const getMedalIcon = (position: number) => {
    if (position === 1) return { icon: Trophy, color: "text-yellow-400", fill: "fill-yellow-400" };
    if (position === 2) return { icon: Trophy, color: "text-gray-300", fill: "fill-gray-300" };
    if (position === 3) return { icon: Trophy, color: "text-orange-600", fill: "fill-orange-600" };
    return { icon: Medal, color: "text-chart-1", fill: "fill-chart-1" };
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-chart-1 selection:text-black">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative min-h-[50vh] flex items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/50 to-background z-10" />
          <motion.img 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 10, ease: "easeOut" }}
            src={heroBg} 
            alt="Western Landscape" 
            className="w-full h-full object-cover"
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center flex flex-col items-center gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ ...spring, delay: 0.1 }}
            className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10 mb-4"
          >
            <Trophy className="w-5 h-5 text-chart-1 fill-chart-1" />
            <span className="text-xs font-bold tracking-widest uppercase text-muted-foreground">Eventos Especiais</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...spring, delay: 0.2 }}
            className="text-5xl md:text-7xl font-heading text-foreground drop-shadow-2xl tracking-tight leading-[0.9]"
          >
            CORRIDA DO
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-chart-1 to-chart-2">OURO</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...spring, delay: 0.3 }}
            className="max-w-2xl text-lg md:text-xl text-muted-foreground font-medium"
          >
            Compete na Corrida do Ouro, ganhe prêmios exclusivos e escale o ranking global dos mineradores
          </motion.p>
        </div>
      </section>

      {/* Main Content */}
      <section className="relative z-20 max-w-7xl mx-auto px-4 md:px-6 py-20">
        {/* Tabs with iOS-style animation */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ ...spring, delay: 0.1 }}
          className="flex gap-4 mb-12 flex-wrap justify-center"
        >
          {[
            { id: "overview", label: "Visão Geral", icon: Sparkles },
            { id: "ranking", label: "Ranking", icon: TrendingUp },
            { id: "prizes", label: "Prêmios", icon: Crown }
          ].map((tab, idx) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.95 }}
                transition={springFast}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold tracking-wider transition-all duration-300 relative ${
                  isActive
                    ? "text-black"
                    : "bg-white/0 border border-white/10 text-muted-foreground hover:bg-white/5"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="tabBackground"
                    className="absolute inset-0 bg-chart-1 rounded-full -z-10 shadow-lg shadow-chart-1/30"
                    transition={{ ...spring }}
                  />
                )}
                <Icon className="w-5 h-5" />
                {tab.label}
              </motion.button>
            );
          })}
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Overview Tab */}
          {activeTab === "overview" && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ ...spring }}
              className="grid md:grid-cols-2 gap-8 mb-16"
            >
              {/* Mining Event Card - Corrida do Ouro */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ ...spring, delay: 0.1 }}
                whileHover={{ y: -8 }}
                className="group relative rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-br from-black/40 to-black/20 backdrop-blur-2xl hover:border-chart-1/50 transition-all duration-300 p-8"
              >
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-br from-chart-1/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  animate={{ backgroundPosition: ["0% 0%", "100% 100%"] }}
                  transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }}
                />
                
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <Pickaxe className="w-8 h-8 text-chart-1 fill-chart-1" />
                        <h3 className="text-2xl font-heading tracking-wider text-foreground">{miningEvent.name}</h3>
                      </div>
                      <motion.p 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.3 }}
                        className="text-sm text-chart-1 font-bold uppercase tracking-widest"
                      >
                        <motion.span
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 1, repeat: Infinity }}
                        >
                          🟢
                        </motion.span>
                        {" "}ATIVO
                      </motion.p>
                    </div>
                  </div>

                  <motion.div 
                    className="space-y-4 mb-6"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    {miningEvent.active && (
                      <>
                        <motion.div 
                          className="flex items-center gap-3 text-muted-foreground"
                          whileHover={{ paddingLeft: 12 }}
                          transition={springFast}
                        >
                          <Timer className="w-5 h-5" />
                          <span className="text-lg font-semibold">
                            {miningEvent.timeRemaining} restante
                          </span>
                        </motion.div>
                        <motion.div 
                          className="flex items-center gap-3 text-muted-foreground"
                          whileHover={{ paddingLeft: 12 }}
                          transition={springFast}
                        >
                          <Medal className="w-5 h-5" />
                          <span className="text-lg font-semibold">
                            Fase {miningEvent.phase} / 7
                          </span>
                        </motion.div>
                      </>
                    )}
                    <motion.div 
                      className="h-2 bg-white/5 rounded-full overflow-hidden"
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      transition={{ ...spring, delay: 0.3 }}
                      style={{ originX: 0 }}
                    >
                      <motion.div
                        className="h-full bg-gradient-to-r from-chart-1 to-chart-2"
                        initial={{ width: "0%" }}
                        whileInView={{ width: "43%" }}
                        transition={{ duration: 1, ease: "easeOut", delay: 0.4 }}
                      />
                    </motion.div>
                  </motion.div>

                  <p className="text-sm text-muted-foreground mb-6">
                    Use <code className="bg-black/40 px-2 py-1 rounded text-chart-1">/mine</code> para minerar ouro e ganhar pontos. Quanto mais minera, mais pontos acumula! Processe o ouro com <code className="bg-black/40 px-2 py-1 rounded text-chart-1">/smelt</code> para dobrar os pontos.
                  </p>

                  <motion.button
                    whileHover={{ scale: 1.08 }}
                    whileTap={{ scale: 0.95 }}
                    transition={springFast}
                    className="w-full py-3 rounded-xl bg-chart-1 text-black font-bold tracking-wider hover:bg-chart-1/90 transition-all shadow-lg shadow-chart-1/20"
                  >
                    VER RANKING
                  </motion.button>
                </div>
              </motion.div>

              {/* Hunting Event Card - Caçada do Xerife */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ ...spring, delay: 0.2 }}
                whileHover={{ y: -8 }}
                className="group relative rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-br from-black/40 to-black/20 backdrop-blur-2xl hover:border-chart-2/50 transition-all duration-300 p-8"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-chart-2/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <Target className="w-8 h-8 text-chart-2" />
                        <h3 className="text-2xl font-heading tracking-wider text-foreground">{huntingEvent.name}</h3>
                      </div>
                      <p className="text-sm text-chart-2 font-bold uppercase tracking-widest">
                        🔴 INATIVO
                      </p>
                    </div>
                  </div>

                  <motion.div 
                    className="space-y-4 mb-6"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <motion.div 
                      className="flex items-center gap-3 text-muted-foreground"
                      whileHover={{ paddingLeft: 12 }}
                      transition={springFast}
                    >
                      <Timer className="w-5 h-5" />
                      <span className="text-lg font-semibold">
                        Nenhum evento ativo
                      </span>
                    </motion.div>
                    <p className="text-sm text-muted-foreground">
                      Eventos de caça são iniciados por administradores do servidor. Fique atento aos anúncios quando eles começarem!
                    </p>
                  </motion.div>

                  <motion.button
                    whileHover={{ scale: 1.08 }}
                    whileTap={{ scale: 0.95 }}
                    transition={springFast}
                    disabled
                    className="w-full py-3 rounded-xl bg-white/5 border border-white/10 text-muted-foreground font-bold tracking-wider cursor-not-allowed opacity-50 transition-all"
                  >
                    EM BREVE
                  </motion.button>
                </div>
              </motion.div>
            </motion.div>
          )}

          {/* Ranking Tab - Top 10 */}
          {activeTab === "ranking" && (
            <motion.div
              key="ranking"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ ...spring }}
              className="space-y-4"
            >
              <motion.div
                className="rounded-3xl overflow-hidden border border-white/10 bg-black/20 backdrop-blur-2xl"
              >
                <motion.div className="p-6 bg-gradient-to-r from-chart-1/10 to-transparent border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <Trophy className="w-5 h-5 text-chart-1 fill-chart-1" />
                    <h3 className="text-lg font-heading tracking-wider text-chart-1">Top 10 Mineradores</h3>
                  </div>
                </motion.div>
                
                {mockLeaderboard.map((entry, idx) => {
                  const medalConfig = getMedalIcon(entry.rank);
                  const IconComponent = medalConfig.icon;
                  return (
                  <motion.div
                    key={entry.rank}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ ...spring, delay: idx * 0.05 }}
                    whileHover={{ 
                      backgroundColor: "rgba(255,255,255,0.08)",
                      paddingRight: 8
                    }}
                    className={`flex items-center justify-between px-6 py-4 border-b border-white/5 cursor-pointer ${
                      idx === 0 ? "bg-chart-1/10" : idx === 1 ? "bg-chart-2/5" : ""
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <motion.div 
                        className="w-12 flex items-center justify-center"
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ delay: idx * 0.05, duration: 2, repeat: Infinity }}
                      >
                        <IconComponent className={`w-8 h-8 ${medalConfig.color} ${medalConfig.fill}`} />
                      </motion.div>
                      <div>
                        <motion.p 
                          className="font-bold text-foreground truncate max-w-[150px] sm:max-w-[200px] md:max-w-[300px]"
                          whileHover={{ color: "#FF6B00" }}
                          transition={springFast}
                        >
                          {entry.username}
                        </motion.p>
                        <p className="text-xs text-muted-foreground">Posição #{entry.rank}</p>
                      </div>
                    </div>
                    <motion.div 
                      className="text-right"
                      whileHover={{ scale: 1.1 }}
                      transition={springFast}
                    >
                      <p className="text-2xl font-heading text-chart-1 tracking-wider">
                        {entry.points.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">OURO</p>
                    </motion.div>
                  </motion.div>
                );
                })}
              </motion.div>
            </motion.div>
          )}

          {/* Prizes Tab - Rewards Structure */}
          {activeTab === "prizes" && (
            <motion.div
              key="prizes"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ ...spring }}
              className="space-y-8"
            >
              {/* Event Selector */}
              <div className="flex gap-4 mb-6">
                <motion.button
                  onClick={() => setSelectedEvent("mining")}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold tracking-wider transition-all ${
                    selectedEvent === "mining"
                      ? "bg-chart-1 text-black shadow-lg shadow-chart-1/20"
                      : "bg-white/5 text-foreground border border-white/10 hover:border-white/20"
                  }`}
                >
                  <Pickaxe className="w-5 h-5" />
                  Corrida do Ouro
                </motion.button>
                <motion.button
                  onClick={() => setSelectedEvent("hunting")}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold tracking-wider transition-all ${
                    selectedEvent === "hunting"
                      ? "bg-chart-2 text-black shadow-lg shadow-chart-2/20"
                      : "bg-white/5 text-foreground border border-white/10 hover:border-white/20"
                  }`}
                >
                  <Target className="w-5 h-5" />
                  Caçada do Xerife
                </motion.button>
              </div>

              <motion.div
                className="rounded-3xl overflow-hidden border border-white/10 bg-black/20 backdrop-blur-2xl"
              >
                <motion.div className="p-6 bg-gradient-to-r from-chart-1/10 to-transparent border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <Coins className="w-5 h-5 text-chart-1" />
                    <h3 className="text-lg font-heading tracking-wider text-chart-1">
                      Prêmios por Posição - {selectedEvent === "mining" ? "Corrida do Ouro" : "Caçada do Xerife"}
                    </h3>
                  </div>
                </motion.div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
                  {(selectedEvent === "mining" ? miningPrizes : huntingPrizes).map((prize, idx) => {
                    const medalConfig = getMedalIcon(prize.position);
                    const IconComponent = medalConfig.icon;
                    return (
                    <motion.div
                      key={prize.position}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ ...spring, delay: idx * 0.05 }}
                      whileHover={{ y: -4, backgroundColor: "rgba(255,255,255,0.08)" }}
                      className="rounded-lg border border-white/10 bg-white/5 p-4 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-center flex-1">
                          <motion.div 
                            className="flex justify-center"
                            animate={{ scale: [1, 1.05, 1] }}
                            transition={{ delay: idx * 0.05, duration: 2, repeat: Infinity }}
                          >
                            <IconComponent className={`w-8 h-8 ${medalConfig.color} ${medalConfig.fill}`} />
                          </motion.div>
                          <p className="text-xs text-muted-foreground mt-1">Posição {prize.position}</p>
                        </div>
                        <Flame className="w-5 h-5 text-chart-1 fill-chart-1" />
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground text-xs uppercase tracking-widest">Moedas</span>
                          <span className="font-bold text-chart-1">{prize.silver.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground text-xs uppercase tracking-widest">Tokens</span>
                          <span className="font-bold text-chart-2">{prize.tokens}x</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground text-xs uppercase tracking-widest">XP</span>
                          <span className="font-bold text-foreground">{prize.xp.toLocaleString()}</span>
                        </div>
                      </div>
                    </motion.div>
                    );
                  })}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ ...spring, delay: 0.2 }}
                whileHover={{ y: -4 }}
                className="rounded-3xl border border-white/10 bg-black/20 backdrop-blur-2xl p-8 cursor-pointer"
              >
                <motion.div className="flex items-center gap-3 mb-4">
                  <Sparkles className="w-6 h-6 text-chart-1 fill-chart-1" />
                  <h4 className="text-xl font-heading tracking-wider">Como ganhar pontos?</h4>
                </motion.div>
                <motion.div 
                  className="space-y-3 text-muted-foreground"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  {[
                    "Use /mine para minerar ouro e ganhar pontos base",
                    "Quanto mais você minera, mais pontos acumula na corrida",
                    "Use /smelt para processar seu ouro e DOBRAR os pontos",
                    "Eventos especiais podem oferecer bônus de 2x ou 3x pontos"
                  ].map((text, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ ...springFast, delay: 0.3 + idx * 0.1 }}
                      whileHover={{ x: 8, color: "#FF6B00" }}
                      className="flex items-center gap-2"
                    >
                      <Zap className="w-4 h-4 text-chart-1 flex-shrink-0" />
                      <span>{text}</span>
                    </motion.div>
                  ))}
                </motion.div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      <Footer />
    </div>
  );
}
