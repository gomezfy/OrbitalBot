import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Loader } from "lucide-react";

interface Stats {
  tokensCirculating: number;
  goldMined: number;
  activeGuilds: number;
  changeTokens: number;
  changeGold: number;
  changeGuilds: number;
  timestamp: string;
}

export default function PublicStats() {
  const { data: stats, isLoading, error, isFetching } = useQuery<Stats>({
    queryKey: ["/api/discord/guilds/1424880033423687887/stats"],
    queryFn: async () => {
      const res = await fetch("/api/discord/guilds/1424880033423687887/stats", {
        credentials: "include",
      });
      if (!res.ok) throw new Error(`${res.status}: ${res.statusText}`);
      return res.json();
    },
    refetchInterval: 5000,
    staleTime: 0,
    retry: 3,
  });

  const statCards = [
    {
      icon: "🔗",
      title: "Tokens em Circulação",
      value: stats ? `${(stats.tokensCirculating / 1000).toFixed(1)}K` : "Carregando...",
      change: stats?.changeTokens || 0,
    },
    {
      icon: "⛏️",
      title: "Ouro Minerado",
      value: stats ? `${stats.goldMined.toFixed(1)}kg` : "Carregando...",
      change: stats?.changeGold || 0,
    },
    {
      icon: "👥",
      title: "Guildas Ativas",
      value: stats?.activeGuilds ?? "Carregando...",
      change: stats?.changeGuilds || 0,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/95">
      {/* Header */}
      <div className="border-b border-border/20 bg-background/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold text-center">Sheriff Rex - Estatísticas Públicas</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="animate-fade-in mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-center">
              Estatísticas em Tempo Real
            </h2>
            <p className="text-muted-foreground text-center">
              Dados ao vivo do servidor Sheriff Rex
            </p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-12">
          {error && (
            <div className="col-span-full flex items-center justify-center py-12">
              <div className="text-center text-red-400">
                <p>Erro ao carregar estatísticas: {(error as Error).message}</p>
              </div>
            </div>
          )}
          {isLoading ? (
            <div className="col-span-full flex items-center justify-center py-12">
              <div className="text-center">
                <Loader className="w-8 h-8 mx-auto mb-3 animate-spin text-primary/50" />
                <p className="text-muted-foreground">Carregando estatísticas...</p>
              </div>
            </div>
          ) : (
            statCards.map((stat) => {
              const isPositive = stat.change >= 0;
              return (
                <div key={stat.title} className="animate-fade-in">
                  <Card className="h-full transition-smooth hover:shadow-2xl hover:shadow-primary/10 border-border/40 hover:border-primary/40 bg-card/60 backdrop-blur-sm overflow-hidden">
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex items-start justify-between">
                          <div className="w-12 h-12 rounded-lg bg-primary/15 flex items-center justify-center hover:bg-primary/25 transition-smooth">
                            <span className="text-xl">{stat.icon}</span>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-sm font-semibold transition-smooth ${
                            isPositive 
                              ? 'bg-emerald-500/20 text-emerald-300' 
                              : 'bg-red-500/20 text-red-300'
                          }`}>
                            {isPositive ? '+' : ''}{stat.change}%
                          </div>
                        </div>

                        <div className="space-y-1">
                          <h3 className="text-2xl md:text-3xl font-bold text-foreground hover:text-primary transition-colors">
                            {stat.value}
                          </h3>
                          <p className="text-muted-foreground text-sm">
                            {stat.title}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              );
            })
          )}
        </div>

        {/* Last Update */}
        {stats && (
          <div className="text-center text-xs text-muted-foreground">
            <p>Última atualização: {new Date(stats.timestamp).toLocaleString('pt-BR')}</p>
          </div>
        )}
      </div>
    </div>
  );
}
