import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Settings, 
  Shield, 
  Coins, 
  Users, 
  BarChart3, 
  LogOut, 
  Menu, 
  X,
  Search,
  Bell,
  Pickaxe,
  Target
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { authApi, statsApi, settingsApi, activityApi } from "@/lib/api";
import { toast } from "sonner";

export default function Dashboard() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const [isLoading, setIsLoading] = useState(true);
  const [userInfo, setUserInfo] = useState<any>(null);
  const [globalStats, setGlobalStats] = useState({
    tokensCirculating: 0,
    goldMined: 0,
    activeGuilds: 0,
    activeBounties: 0,
    changeTokens: 0,
    changeGold: 0,
    changeGuilds: 0,
    changeBounties: 0,
  });

  const [stats, setStats] = useState({
    tokensCirculating: 0,
    goldMined: 0,
    activeGuilds: 0,
    activeBounties: 0,
    totalMembers: 0,
    commandsToday: 0,
  });

  const [settings, setSettings] = useState({
    dailyRewardsEnabled: true,
    xpSystemEnabled: true,
    territoriesEnabled: true,
    autoWantedEnabled: false,
  });

  const [activityData, setActivityData] = useState<number[]>([]);

  useEffect(() => {
    loadGlobalStats();
    loadDashboardData();
    const interval = setInterval(loadGlobalStats, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadGlobalStats = async () => {
    try {
      const res = await fetch("/api/discord/guilds/1424880033423687887/stats", {
        credentials: "include",
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setGlobalStats({
        tokensCirculating: data.tokensCirculating || 0,
        goldMined: data.goldMined || 0,
        activeGuilds: data.activeGuilds || 0,
        activeBounties: data.activeBounties || 0,
        changeTokens: data.changeTokens || 0,
        changeGold: data.changeGold || 0,
        changeGuilds: data.changeGuilds || 0,
        changeBounties: data.changeBounties || 0,
      });
    } catch (error) {
      // Silently fail for global stats
    }
  };

  const loadDashboardData = async () => {
    try {
      const [statsData, settingsData, activityLogs, meData] = await Promise.all([
        statsApi.get(),
        settingsApi.get(),
        activityApi.get(),
        authApi.me(),
      ]);

      // Carregar informações do usuário
      if (meData) {
        setUserInfo(meData);
      }

      if (statsData) {
        const data = statsData as any;
        setStats({
          tokensCirculating: data.tokensCirculating || 0,
          goldMined: data.goldMined || 0,
          activeGuilds: data.activeGuilds || 0,
          activeBounties: data.activeBounties || 0,
          totalMembers: data.totalMembers || 0,
          commandsToday: data.commandsToday || 0,
        });
      }

      if (settingsData) {
        const data = settingsData as any;
        setSettings({
          dailyRewardsEnabled: data.dailyRewardsEnabled ?? true,
          xpSystemEnabled: data.xpSystemEnabled ?? true,
          territoriesEnabled: data.territoriesEnabled ?? true,
          autoWantedEnabled: data.autoWantedEnabled ?? false,
        });
      }
      
      if (Array.isArray(activityLogs) && activityLogs.length > 0) {
        const activityValues = activityLogs.map((log: any) => Math.round((log.economicActivity / 150)));
        setActivityData(activityValues);
      } else {
        setActivityData([40, 65, 45, 80, 55, 90, 75]);
      }
      
      setIsLoading(false);
    } catch (error: any) {
      // Mock persistence fallback for prototype mode
      if (localStorage.getItem("mock_session") === "true") {
        setUserInfo({ 
          discordUsername: "Admin", 
          role: "admin",
          discordAvatar: "/assets/images/sheriff_rex_avatar.png" 
        });
        
        // Mock data fallback
        setStats({
          tokensCirculating: 125000,
          goldMined: 450.5,
          activeGuilds: 12,
          activeBounties: 5,
          totalMembers: 156,
          commandsToday: 342
        });
        
        setActivityData([40, 65, 45, 80, 55, 90, 75]);
        setIsLoading(false);
        return;
      }

      toast.error("Erro ao carregar dados do dashboard");
      if (error.status === 401) {
        setLocation("/login");
      }
    }
  };

  const toggleSetting = async (key: keyof typeof settings) => {
    const newSettings = { ...settings, [key]: !settings[key] };
    setSettings(newSettings);
    
    try {
      await settingsApi.update(newSettings);
      toast.success("Configuração atualizada!");
    } catch (error: any) {
      setSettings(settings);
      toast.error("Erro ao atualizar configuração");
    }
  };

  const handleLogout = async () => {
    try {
      await authApi.logout();
      toast.success("Logout realizado!");
      setLocation("/login");
    } catch (error: any) {
      toast.error("Erro ao fazer logout");
    }
  };

  const menuItems = [
    { id: "overview", label: "Visão Geral", icon: LayoutDashboard },
    { id: "servers", label: "Gerenciar Servidores", icon: Shield, action: "navigate" },
    { id: "economy", label: "Economia & Lojas", icon: Coins },
    { id: "guilds", label: "Guildas", icon: Users },
    { id: "mining", label: "Mineração", icon: Pickaxe },
    { id: "bounties", label: "Procurados", icon: Target },
    { id: "settings", label: "Configurações", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background flex overflow-hidden">
      {/* Mobile Backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ 
          x: isSidebarOpen ? 0 : -280,
        }}
        transition={{ type: "spring", damping: 20, stiffness: 300 }}
        className="fixed inset-y-0 left-0 z-50 w-[280px] bg-card border-r border-white/5 flex flex-col md:relative md:translate-x-0"
      >
        <div className="p-6 flex items-center gap-3 border-b border-white/5 h-20">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-chart-1">
             <img src="/assets/images/sheriff_rex_avatar.png" alt="Logo" className="w-full h-full object-cover" />
          </div>
          <span className="font-heading text-xl tracking-wider whitespace-nowrap">SHERIFF REX</span>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item: any) => (
            <button
              key={item.id}
              onClick={() => {
                if (item.action === "navigate") {
                  setLocation(`/${item.id}`);
                } else {
                  setActiveTab(item.id);
                  if (window.innerWidth < 768) {
                    setSidebarOpen(false);
                  }
                }
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                activeTab === item.id 
                  ? "bg-chart-1 text-black font-bold shadow-lg shadow-chart-1/20" 
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <item.icon className={`w-5 h-5 ${activeTab === item.id ? "text-black" : "group-hover:text-chart-1"}`} />
              <span className="whitespace-nowrap">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <Button 
            variant="ghost" 
            className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-500/10"
            onClick={handleLogout}
          >
            <LogOut className="w-5 h-5 mr-3" />
            Sair
          </Button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 relative">
        {/* Header */}
        <header className="h-20 border-b border-white/5 bg-background/80 backdrop-blur-md sticky top-0 z-40 px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!isSidebarOpen)}>
              <Menu className="w-5 h-5" />
            </Button>
            <h2 className="text-xl font-heading hidden md:block">
              {menuItems.find(i => i.id === activeTab)?.label}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input 
                placeholder="Buscar comando..." 
                className="pl-10 w-64 bg-white/5 border-white/10 focus:border-chart-1 rounded-full"
              />
            </div>
            
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-chart-2 rounded-full animate-pulse" />
            </Button>

            <div className="flex items-center gap-3 border-l border-white/10 pl-4">
              <div className="text-right hidden md:block">
                <p className="text-sm font-medium">{userInfo?.discordUsername || 'Carregando...'}</p>
                <p className="text-xs text-muted-foreground">{userInfo?.role === 'admin' ? 'Administrador' : 'Usuário'}</p>
              </div>
              <Avatar className="border border-white/10 cursor-pointer hover:border-chart-1 transition-colors">
                <AvatarImage src={userInfo?.discordAvatar} alt={userInfo?.discordUsername} />
                <AvatarFallback>{userInfo?.discordUsername?.substring(0, 2).toUpperCase() || 'US'}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-6xl mx-auto space-y-8">
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: "Tokens em Circulação", value: `${(globalStats.tokensCirculating / 1000).toFixed(1)}K`, change: `${globalStats.changeTokens > 0 ? '+' : ''}${globalStats.changeTokens}%`, icon: Coins, color: "text-yellow-400" },
                { label: "Ouro Minerado", value: `${globalStats.goldMined.toFixed(1)}kg`, change: `${globalStats.changeGold > 0 ? '+' : ''}${globalStats.changeGold}%`, icon: Pickaxe, color: "text-chart-1" },
                { label: "Guildas Ativas", value: globalStats.activeGuilds.toString(), change: `${globalStats.changeGuilds > 0 ? '+' : ''}${globalStats.changeGuilds}`, icon: Users, color: "text-blue-400" },
                { label: "Procurados Ativos", value: globalStats.activeBounties.toString(), change: `${globalStats.changeBounties > 0 ? '+' : ''}${globalStats.changeBounties}`, icon: Target, color: "text-red-400" }
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card className="bg-card border-white/5 hover:border-white/10 transition-all">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className={`p-3 rounded-xl bg-white/5 ${stat.color}`}>
                          <stat.icon className="w-6 h-6" />
                        </div>
                        <span className={`text-xs font-bold px-2 py-1 rounded-full ${stat.change.startsWith('+') ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                          {stat.change}
                        </span>
                      </div>
                      <h3 className="text-3xl font-heading mb-1">{stat.value}</h3>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Fake Activity Chart */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="lg:col-span-2 bg-card border-white/5">
                <CardHeader>
                  <CardTitle>Atividade Econômica (Tokens/Dia)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-end justify-between gap-2 px-4">
                    {activityData.map((h, i) => (
                      <motion.div
                        key={i}
                        initial={{ height: 0 }}
                        animate={{ height: `${h}%` }}
                        transition={{ duration: 1, delay: i * 0.1 }}
                        className="w-full bg-chart-1/20 hover:bg-chart-1 rounded-t-lg relative group transition-colors"
                      >
                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                          {h * 150}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <div className="flex justify-between mt-4 text-xs text-muted-foreground uppercase px-4">
                    <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sab</span><span>Dom</span>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Settings */}
              <Card className="bg-card border-white/5">
                <CardHeader>
                  <CardTitle>Controles do Sistema</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {[
                    { id: "dailyRewardsEnabled", label: "Daily Rewards Auto", desc: "Distribuir às 21:00" },
                    { id: "xpSystemEnabled", label: "Sistema de XP", desc: "Ganho de experiência ativo" },
                    { id: "territoriesEnabled", label: "Controle de Territórios", desc: "Disputa de guildas" },
                    { id: "autoWantedEnabled", label: "Procurados Auto", desc: "Gerar NPCs procurados" }
                  ].map((setting) => (
                    <div key={setting.id} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{setting.label}</p>
                        <p className="text-xs text-muted-foreground">{setting.desc}</p>
                      </div>
                      <Switch 
                        checked={settings[setting.id as keyof typeof settings]} 
                        onCheckedChange={() => toggleSetting(setting.id as keyof typeof settings)}
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
