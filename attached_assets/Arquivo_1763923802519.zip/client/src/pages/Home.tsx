import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Stats } from "@/components/Stats";
import { Features } from "@/components/Features";
import { Showcase } from "@/components/Showcase";
import { Commands } from "@/components/Commands";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-chart-1 selection:text-black">
      <Navbar />
      <Hero />
      <Stats />
      <Features />
      <Showcase />
      <Commands />
      <Footer />
    </div>
  );
}
