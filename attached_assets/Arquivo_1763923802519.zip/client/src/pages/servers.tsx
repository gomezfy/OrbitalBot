import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings, Users, ArrowRight } from "lucide-react";

interface Guild {
  id: string;
  name: string;
  icon: string | null;
  memberCount: number;
}

export default function Servers() {
  const [, setLocation] = useLocation();
  
  const { data: guilds, isLoading, isError, error } = useQuery<Guild[]>({
    queryKey: ["/api/discord/guilds"],
  });

  useEffect(() => {
    if (isError && error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      if (errorMessage.includes("401")) {
        setLocation("/login");
      }
    }
  }, [isError, error, setLocation]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center animate-fade-in">
          <div className="w-12 h-12 rounded-full bg-primary/20 mx-auto mb-4 animate-pulse" />
          <h2 className="text-2xl font-bold mb-2">Carregando servidores...</h2>
          <p className="text-muted-foreground">Aguarde enquanto buscamos seus servidores</p>
        </div>
      </div>
    );
  }

  if (!guilds || guilds.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center max-w-md animate-fade-in">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
            <Users className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="text-3xl font-bold mb-3">Nenhum servidor encontrado</h2>
          <p className="text-muted-foreground mb-8 leading-relaxed">
            Você precisa ser administrador de um servidor Discord onde o Sheriff Rex está presente para gerenciá-lo aqui.
          </p>
          <Button data-testid="button-back-home" asChild size="lg">
            <Link href="/" className="gap-2">
              Voltar ao início
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/95">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="animate-fade-in mb-12">
          <div className="space-y-3 mb-2">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight" data-testid="heading-servers">
              Meus Servidores
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Gerenciador de servidores Discord com Sheriff Rex
            </p>
          </div>
          <div className="h-1 w-20 bg-gradient-to-r from-primary to-accent rounded-full mt-4" />
        </div>

        {/* Guilds Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {guilds.map((guild, index) => (
            <Link key={guild.id} href={`/servers/${guild.id}/config`}>
              <div 
                className={`animate-stagger-item guild-card-${Math.min(index, 5)} group cursor-pointer h-full`}
                data-testid={`card-guild-${guild.id}`}
              >
                <Card className="h-full transition-smooth hover:shadow-2xl hover:shadow-primary/10 border-border/40 hover:border-primary/40 bg-card/60 backdrop-blur-sm overflow-hidden">
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-4 flex-1 min-w-0">
                        {/* Icon */}
                        <div className="flex-shrink-0">
                          {guild.icon ? (
                            <img
                              src={guild.icon}
                              alt={guild.name}
                              className="w-14 h-14 rounded-xl object-cover shadow-lg group-hover:shadow-primary/30 transition-smooth ring-1 ring-white/10"
                              data-testid={`img-guild-icon-${guild.id}`}
                            />
                          ) : (
                            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center shadow-lg ring-1 ring-white/10">
                              <Users className="w-7 h-7 text-primary/60" />
                            </div>
                          )}
                        </div>
                        
                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <h3 
                            className="text-lg font-semibold truncate text-foreground group-hover:text-primary transition-colors" 
                            data-testid={`text-guild-name-${guild.id}`}
                          >
                            {guild.name}
                          </h3>
                          <p 
                            className="text-sm text-muted-foreground flex items-center gap-1 mt-1 transition-smooth group-hover:text-muted-foreground/80"
                            data-testid={`text-guild-members-${guild.id}`}
                          >
                            <Users className="w-3.5 h-3.5" />
                            {guild.memberCount.toLocaleString('pt-BR')} membros
                          </p>
                        </div>
                      </div>

                      {/* Arrow indicator */}
                      <div className="flex-shrink-0 w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-smooth">
                        <ArrowRight className="w-4 h-4 text-primary/60 group-hover:text-primary group-hover:translate-x-0.5 transition-smooth" />
                      </div>
                    </div>
                  </CardHeader>

                  {/* Action Button */}
                  <CardContent className="pt-2">
                    <Button 
                      variant="secondary"
                      className="w-full transition-smooth group-hover:bg-primary group-hover:text-primary-foreground"
                      asChild
                      data-testid={`button-configure-${guild.id}`}
                    >
                      <div className="flex items-center justify-center gap-2">
                        <Settings className="w-4 h-4" />
                        <span>Configurar</span>
                      </div>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </Link>
          ))}
        </div>

        {/* Stats Footer */}
        <div className="mt-16 pt-8 border-t border-border/20">
          <p className="text-center text-sm text-muted-foreground">
            {guilds.length} servidor{guilds.length !== 1 ? 'es' : ''} disponível{guilds.length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>
    </div>
  );
}
