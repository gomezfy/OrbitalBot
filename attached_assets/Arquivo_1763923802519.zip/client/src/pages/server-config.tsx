import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

const configSchema = z.object({
  language: z.string(),
  prefix: z.string().min(1).max(5),
  logChannelId: z.string().transform(val => val || undefined).optional(),
  loggingEnabled: z.boolean(),
  welcomeChannelId: z.string().transform(val => val || undefined).optional(),
  welcomeMessage: z.string().transform(val => val || undefined).optional(),
  welcomeEnabled: z.boolean(),
  autoModEnabled: z.boolean(),
  antiSpamEnabled: z.boolean(),
  antiRaidEnabled: z.boolean(),
  economyEnabled: z.boolean(),
  levelsEnabled: z.boolean(),
  bountiesEnabled: z.boolean(),
  announcementChannelId: z.string().transform(val => val || undefined).optional(),
}).refine((data) => {
  if (data.loggingEnabled && !data.logChannelId) {
    return false;
  }
  if (data.welcomeEnabled && !data.welcomeChannelId) {
    return false;
  }
  return true;
}, {
  message: "Campos obrigatórios quando recursos estão habilitados",
});

type ConfigFormData = z.infer<typeof configSchema>;

interface GuildConfig {
  guildId: string;
  guildName: string;
  language: string;
  prefix: string;
  logChannelId?: string | null;
  loggingEnabled: boolean;
  welcomeChannelId?: string | null;
  welcomeMessage?: string | null;
  welcomeEnabled: boolean;
  autoModEnabled: boolean;
  antiSpamEnabled: boolean;
  antiRaidEnabled: boolean;
  economyEnabled: boolean;
  levelsEnabled: boolean;
  bountiesEnabled: boolean;
  announcementChannelId?: string | null;
}

interface Channel {
  id: string;
  name: string;
  type: number;
  position: number;
}

export default function ServerConfig() {
  const [, params] = useRoute("/servers/:guildId/config");
  const guildId = params?.guildId;
  const { toast } = useToast();

  const { data: config, isLoading: configLoading, error: configError } = useQuery<GuildConfig>({
    queryKey: [`/api/discord/guilds/${guildId}/config`],
    enabled: !!guildId,
  });

  const { data: channels, error: channelsError } = useQuery<Channel[]>({
    queryKey: [`/api/discord/guilds/${guildId}/channels`],
    enabled: !!guildId,
  });

  const form = useForm<ConfigFormData>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      language: "pt-BR",
      prefix: "/",
      logChannelId: "",
      loggingEnabled: false,
      welcomeChannelId: "",
      welcomeMessage: "",
      welcomeEnabled: false,
      autoModEnabled: false,
      antiSpamEnabled: false,
      antiRaidEnabled: false,
      economyEnabled: true,
      levelsEnabled: true,
      bountiesEnabled: true,
      announcementChannelId: "",
    },
    values: config ? {
      language: config.language || "pt-BR",
      prefix: config.prefix || "/",
      logChannelId: config.logChannelId || "",
      loggingEnabled: config.loggingEnabled || false,
      welcomeChannelId: config.welcomeChannelId || "",
      welcomeMessage: config.welcomeMessage || "",
      welcomeEnabled: config.welcomeEnabled || false,
      autoModEnabled: config.autoModEnabled || false,
      antiSpamEnabled: config.antiSpamEnabled || false,
      antiRaidEnabled: config.antiRaidEnabled || false,
      economyEnabled: config.economyEnabled !== undefined ? config.economyEnabled : true,
      levelsEnabled: config.levelsEnabled !== undefined ? config.levelsEnabled : true,
      bountiesEnabled: config.bountiesEnabled !== undefined ? config.bountiesEnabled : true,
      announcementChannelId: config.announcementChannelId || "",
    } : undefined,
  });

  const updateMutation = useMutation({
    mutationFn: async (data: ConfigFormData) => {
      return apiRequest("PUT", `/api/discord/guilds/${guildId}/config`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/discord/guilds/${guildId}/config`] });
      toast({
        title: "Configurações salvas",
        description: "As configurações do servidor foram atualizadas com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao salvar",
        description: error.message || "Ocorreu um erro ao atualizar as configurações.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ConfigFormData) => {
    updateMutation.mutate(data);
  };

  const loggingEnabled = form.watch("loggingEnabled") || false;
  const welcomeEnabled = form.watch("welcomeEnabled") || false;

  if (configError) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="max-w-md border-destructive/50">
          <CardHeader>
            <CardTitle className="text-destructive">Erro ao carregar configurações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">{configError.message}</p>
            <Button variant="outline" asChild>
              <Link href="/servers">Voltar aos servidores</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (configLoading || !config) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Carregando configurações...</h2>
          <p className="text-muted-foreground">Aguarde um momento</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl">
      <div className="mb-6">
        <Button variant="ghost" asChild data-testid="button-back-servers">
          <Link href="/servers">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar aos servidores
          </Link>
        </Button>
      </div>

      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2" data-testid="heading-server-name">{config.guildName}</h1>
        <p className="text-muted-foreground">Configure o Sheriff Rex para este servidor</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
              <CardDescription>Defina o idioma e o prefixo dos comandos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="language"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Idioma</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-language">
                          <SelectValue placeholder="Selecione o idioma" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="es-ES">Español</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Idioma das mensagens do bot
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="prefix"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prefixo dos Comandos</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="/" maxLength={5} data-testid="input-prefix" />
                    </FormControl>
                    <FormDescription>
                      Prefixo para invocar comandos do bot (máximo 5 caracteres)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Registro de Atividades</CardTitle>
              <CardDescription>Configure o sistema de logs do servidor</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="loggingEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Ativar Logs</FormLabel>
                      <FormDescription>
                        Registrar ações de moderação e eventos importantes
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-logging"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {loggingEnabled && (
                <FormField
                  control={form.control}
                  name="logChannelId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Canal de Logs</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-log-channel">
                            <SelectValue placeholder="Selecione um canal" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {channels?.map((ch) => (
                            <SelectItem key={ch.id} value={ch.id}>
                              #{ch.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Canal onde os logs serão enviados
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Boas-vindas</CardTitle>
              <CardDescription>Configure mensagens de boas-vindas para novos membros</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="welcomeEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Ativar Boas-vindas</FormLabel>
                      <FormDescription>
                        Enviar mensagem quando um novo membro entrar
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-welcome"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {welcomeEnabled && (
                <>
                  <FormField
                    control={form.control}
                    name="welcomeChannelId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Canal de Boas-vindas</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || ""}>
                          <FormControl>
                            <SelectTrigger data-testid="select-welcome-channel">
                              <SelectValue placeholder="Selecione um canal" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {channels?.map((ch) => (
                              <SelectItem key={ch.id} value={ch.id}>
                                #{ch.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="welcomeMessage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mensagem de Boas-vindas</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="Bem-vindo ao servidor, {user}!" 
                            data-testid="input-welcome-message"
                          />
                        </FormControl>
                        <FormDescription>
                          Use {'{user}'} para mencionar o novo membro
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Moderação Automática</CardTitle>
              <CardDescription>Configure sistemas de proteção automática</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="autoModEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Auto-Moderação</FormLabel>
                      <FormDescription>
                        Moderação automática de conteúdo
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-auto-mod"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="antiSpamEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Anti-Spam</FormLabel>
                      <FormDescription>
                        Prevenir spam de mensagens
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-anti-spam"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="antiRaidEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Anti-Raid</FormLabel>
                      <FormDescription>
                        Proteção contra invasões em massa
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-anti-raid"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sistemas do Bot</CardTitle>
              <CardDescription>Habilitar ou desabilitar funcionalidades</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="economyEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Sistema de Economia</FormLabel>
                      <FormDescription>
                        Moedas, recompensas e loja
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-economy"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="levelsEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Sistema de Níveis</FormLabel>
                      <FormDescription>
                        XP e níveis por atividade
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-levels"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="bountiesEnabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-md border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Sistema de Recompensas</FormLabel>
                      <FormDescription>
                        Missões e recompensas por caça
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-bounties"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Button
              type="submit"
              disabled={updateMutation.isPending}
              data-testid="button-save-config"
            >
              {updateMutation.isPending ? (
                "Salvando..."
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Configurações
                </>
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
