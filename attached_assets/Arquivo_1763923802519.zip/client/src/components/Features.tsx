import { motion } from "framer-motion";
import { ArrowRight, Coins, Dice5, Pickaxe, Crosshair, Target, Shield } from "lucide-react";

const features = [
  {
    icon: Coins,
    title: "Economia",
    description: "Sistema duplo de moedas (Saloon Tokens e Silver Coins), recompensas diárias, comércio seguro e muito mais!",
    color: "text-yellow-500"
  },
  {
    icon: Dice5,
    title: "Jogos e Diversão",
    description: "Dados, duelos PvP, roleta, assalto ao banco e diversos minigames para sua comunidade se divertir!",
    color: "text-purple-500"
  },
  {
    icon: Pickaxe,
    title: "Mineração",
    description: "Minere ouro, prata e gemas! Modo solo e cooperativo com eventos semanais competitivos!",
    color: "text-blue-500"
  },
  {
    icon: Crosshair, // Using Crosshair as fallback for hunting/deer
    title: "Caça e Pesca",
    description: "Sistema interativo de caça com 5 tentativas por sessão e pesca com timing preciso. Venda suas presas no Hunter's Store!",
    color: "text-green-500"
  },
  {
    icon: Target,
    title: "Recompensas",
    description: "Coloque recompensas em usuários, capture procurados e ganhe prêmios! Sistema solo e em equipe!",
    color: "text-red-500"
  },
  {
    icon: Shield,
    title: "Moderação",
    description: "Avisos, mutes, sistema de punições e logs detalhados para manter seu servidor seguro!",
    color: "text-indigo-500"
  }
];

export function Features() {
  return (
    <section id="features" className="py-20 md:py-32 relative bg-background overflow-hidden">
      {/* Texture overlay */}
      <div className="absolute inset-0 leather-texture opacity-50" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-heading mb-6"
          >
            AUMENTE O <span className="text-chart-1">ENGAJAMENTO</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Com o Sheriff Rex as interações aumentarão sempre mais!
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-panel p-8 rounded-2xl border border-white/5 hover:border-chart-1/50 transition-colors group"
            >
              <div className={`w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 ${feature.color}`}>
                <feature.icon className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-heading mb-4 text-foreground">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                {feature.description}
              </p>
              <a href="#commands" className="inline-flex items-center text-sm font-bold uppercase tracking-widest text-chart-1 hover:text-chart-2 transition-colors">
                Ver Comandos <ArrowRight className="ml-2 w-4 h-4" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
