import { motion } from "framer-motion";
import { User, ShieldCheck, Check } from "lucide-react";

export function Showcase() {
  return (
    <section className="py-32 bg-background relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Visual Profiles */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-20 lg:mb-32">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <h2 className="text-4xl md:text-5xl font-heading mb-8">
              PERFIS VISUAIS <br />
              <span className="text-chart-1">PERSONALIZADOS</span>
            </h2>
            <ul className="space-y-6">
              {[
                "Cartões de perfil gerados dinamicamente",
                "Sistema de XP e níveis",
                "Inventário visual com itens",
                "Pôsteres de procurados customizados"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-4 text-lg text-muted-foreground">
                  <div className="w-8 h-8 rounded-full bg-chart-1/20 flex items-center justify-center text-chart-1">
                    <Check className="w-4 h-4" />
                  </div>
                  {item}
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2"
          >
            <div className="aspect-square rounded-3xl bg-linear-to-br from-chart-1/20 to-transparent border border-chart-1/30 p-8 flex items-center justify-center relative">
              <div className="absolute inset-0 bg-chart-1/5 blur-3xl rounded-full" />
              <div className="glass-panel p-12 rounded-2xl text-center border-2 border-chart-1 relative z-10">
                <User className="w-24 h-24 mx-auto text-chart-1 mb-6" />
                <p className="font-heading text-2xl">SISTEMA CANVAS</p>
                <p className="text-muted-foreground mt-2">Perfis Dinâmicos</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Protection */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
             <div className="aspect-square rounded-3xl bg-linear-to-br from-chart-2/20 to-transparent border border-chart-2/30 p-8 flex items-center justify-center relative">
              <div className="absolute inset-0 bg-chart-2/5 blur-3xl rounded-full" />
              <div className="glass-panel p-12 rounded-2xl text-center border-2 border-chart-2 relative z-10">
                <ShieldCheck className="w-24 h-24 mx-auto text-chart-2 mb-6" />
                <p className="font-heading text-2xl">PROTEÇÃO TOTAL</p>
                <p className="text-muted-foreground mt-2">Anti-Raid System</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-heading mb-8">
              PROTEJA SEU SERVIDOR <br />
              <span className="text-chart-2">CONTRA ATAQUES</span>
            </h2>
            <ul className="space-y-6">
              {[
                "Anti-spam inteligente",
                "Sistema de avisos e punições",
                "Logs detalhados de moderação",
                "Comandos de moderação completos"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-4 text-lg text-muted-foreground">
                  <div className="w-8 h-8 rounded-full bg-chart-2/20 flex items-center justify-center text-chart-2">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  {item}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
