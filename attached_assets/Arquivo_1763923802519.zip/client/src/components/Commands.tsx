import { motion } from "framer-motion";
import { Shield, Coins, Dice5, Pickaxe, Target, Users, User, Settings } from "lucide-react";

const categories = [
  { icon: Shield, name: "Admin", desc: "Painel, Embeds, Boas-vindas" },
  { icon: Coins, name: "Economia", desc: "Daily, Expedições, Territórios" },
  { icon: Dice5, name: "Gambling", desc: "Dados, Duelo, Roleta, Roubo" },
  { icon: Pickaxe, name: "Mineração", desc: "Minerar recursos preciosos" },
  { icon: Target, name: "Bounty", desc: "Procurados e Capturas" },
  { icon: Users, name: "Guilda", desc: "Gestão de clãs e equipes" },
  { icon: User, name: "Perfil", desc: "Inventário e Status" },
  { icon: Settings, name: "Utilidades", desc: "Ajuda, Ping, Enquetes" },
];

export function Commands() {
  return (
    <section id="commands" className="py-20 md:py-32 bg-background/50 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-5xl font-heading mb-4">COMANDOS DISPONÍVEIS</h2>
          <p className="text-muted-foreground text-lg">Sistema completo com 8 categorias principais</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {categories.map((cat, index) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              viewport={{ once: true }}
              className="glass-panel p-6 rounded-xl text-center hover:bg-white/5 transition-colors cursor-pointer border border-white/5 hover:border-chart-1/30"
            >
              <cat.icon className="w-10 h-10 mx-auto text-chart-1 mb-4" />
              <h3 className="font-heading text-xl mb-2">{cat.name}</h3>
              <p className="text-sm text-muted-foreground">{cat.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
