import { motion } from "framer-motion";
import { ArrowRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBotInfo } from "@/hooks/use-bot-info";
import { useLocation } from "wouter";

export function Hero() {
  const heroBg = "/assets/images/western_landscape_hero_background.png";
  const { data: botInfo } = useBotInfo();
  const [, setLocation] = useLocation();
  
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Image with Parallax-like scale */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/50 to-background z-10" />
        <motion.img 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 10, ease: "easeOut" }}
          src={heroBg} 
          alt="Western Landscape" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center flex flex-col items-center gap-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 mb-4"
        >
          <Star className="w-4 h-4 text-chart-1 fill-chart-1" />
          <span className="text-xs font-bold tracking-widest uppercase text-muted-foreground">O Xerife do Velho Oeste</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-4xl md:text-7xl lg:text-9xl font-heading text-foreground drop-shadow-2xl tracking-tight leading-[0.9]"
        >
          AS MELHORES <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-b from-chart-1 to-chart-2 text-glow">FUNCIONALIDADES</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="max-w-2xl text-lg md:text-xl text-muted-foreground font-medium leading-relaxed"
        >
          Economia, diversão, moderação, caça, mineração e muito mais para o seu servidor.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center gap-4 mt-4"
        >
          <Button 
            size="lg" 
            className="h-14 px-8 rounded-full bg-chart-1 text-black hover:bg-chart-1/90 font-bold tracking-widest text-lg shadow-lg shadow-chart-1/20 group"
            onClick={() => {
              if (botInfo?.inviteUrl) {
                window.open(botInfo.inviteUrl, '_blank');
              }
            }}
            disabled={!botInfo?.inviteUrl}
          >
            ADICIONAR AGORA
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="h-14 px-8 rounded-full bg-white/5 border-white/10 text-foreground hover:bg-white/10 font-bold tracking-widest text-lg backdrop-blur-sm"
            onClick={() => setLocation('/dashboard')}
          >
            DASHBOARD
          </Button>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Deslize para explorar</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-chart-1/0 via-chart-1 to-chart-1/0" />
      </motion.div>
    </section>
  );
}
