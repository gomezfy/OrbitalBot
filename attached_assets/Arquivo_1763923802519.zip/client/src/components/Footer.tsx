import { Button } from "@/components/ui/button";
import { Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-background border-t border-white/10 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* CTA Section */}
        <div className="text-center mb-20 pb-20 border-b border-white/5">
          <h2 className="text-4xl md:text-5xl font-heading mb-10">
            E AÍ, TÁ ESPERANDO O QUÊ <br />
            PRA ME ADICIONAR?
          </h2>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="h-14 px-10 rounded-full bg-chart-1 text-black hover:bg-chart-1/90 font-bold tracking-widest text-lg">
              ADICIONAR AO SERVIDOR
            </Button>
            <Button size="lg" variant="outline" className="h-14 px-10 rounded-full bg-transparent border-chart-1 text-chart-1 hover:bg-chart-1/10 font-bold tracking-widest text-lg">
              DASHBOARD
            </Button>
          </div>
        </div>

        {/* Footer Content */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🤠</span>
            <span className="font-heading text-xl tracking-wider">SHERIFF REX BOT</span>
          </div>
          
          <div className="flex gap-8 text-sm text-muted-foreground font-medium uppercase tracking-wider">
            <a href="#" className="hover:text-chart-1 transition-colors">Termos de Serviço</a>
            <a href="#" className="hover:text-chart-1 transition-colors">Privacidade</a>
            <a href="https://github.com/gomezfy/Sheriffbot-" target="_blank" className="hover:text-chart-1 transition-colors flex items-center gap-2">
              <Github className="w-4 h-4" /> GitHub
            </a>
          </div>
        </div>
        
        <div className="text-center mt-12 pt-8 border-t border-white/5 text-xs text-muted-foreground uppercase tracking-widest">
          &copy; 2025 Sheriff Rex Bot. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
