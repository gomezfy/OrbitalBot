import { Link } from "wouter";
import { motion } from "framer-motion";
import { Menu, X, Github } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useBotInfo } from "@/hooks/use-bot-info";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const cowboyRobot = "/assets/images/sheriff_rex_avatar.png";
  const { data: botInfo } = useBotInfo();

  const navLinks = [
    { name: "Eventos", href: "/evento" },
    { name: "Funcionalidades", href: "#features" },
    { name: "Comandos", href: "#commands" },
    { name: "Dashboard", href: "/login" },
  ];

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 left-0 right-0 z-50 px-4 md:px-6 py-4"
    >
      <div className="glass-panel max-w-7xl mx-auto rounded-full px-4 md:px-6 py-3 flex items-center justify-between relative overflow-hidden">
        {/* Shine effect */}
        <div className="absolute inset-0 pointer-events-none bg-linear-to-r from-transparent via-white/5 to-transparent skew-x-12 translate-x-[-100%] animate-[shimmer_8s_infinite]" />
        
        <Link href="/">
          <div className="flex items-center gap-3 cursor-pointer group">
            <div className="relative w-10 h-10 rounded-full overflow-hidden border-2 border-ring shadow-lg group-hover:scale-105 transition-transform duration-300">
              <img src={cowboyRobot} alt="Sheriff Rex" className="w-full h-full object-cover" />
            </div>
            <span className="font-heading text-xl tracking-wider text-foreground group-hover:text-chart-1 transition-colors">SHERIFF REX</span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium text-muted-foreground hover:text-chart-1 transition-colors uppercase tracking-widest"
            >
              {link.name}
            </a>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground hover:text-foreground hover:bg-white/5" asChild>
            <a href="https://github.com/gomezfy/Sheriffbot-" target="_blank" rel="noopener noreferrer">
              <Github className="w-5 h-5" />
            </a>
          </Button>
          <Button 
            className="rounded-full bg-chart-1 text-black hover:bg-chart-1/90 font-bold tracking-wider px-6 shadow-lg shadow-chart-1/20"
            onClick={() => {
              if (botInfo?.inviteUrl) {
                window.open(botInfo.inviteUrl, '_blank');
              }
            }}
            disabled={!botInfo?.inviteUrl}
          >
            ADICIONAR AO SERVIDOR
          </Button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-foreground" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="absolute top-24 left-6 right-6 md:hidden"
        >
          <div className="glass-panel rounded-2xl p-6 flex flex-col gap-4">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className="text-lg font-heading text-center py-2 border-b border-white/5 hover:text-chart-1 transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <Button 
              className="w-full rounded-full bg-chart-1 text-black font-bold mt-2"
              onClick={() => {
                if (botInfo?.inviteUrl) {
                  window.open(botInfo.inviteUrl, '_blank');
                }
                setIsOpen(false);
              }}
              disabled={!botInfo?.inviteUrl}
            >
              ADICIONAR AO SERVIDOR
            </Button>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}
