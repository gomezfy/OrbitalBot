import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { Gamepad2, Globe, Zap } from "lucide-react";

const stats = [
  { label: "Comandos", value: 47, icon: Gamepad2, color: "from-blue-500 to-cyan-500", iconColor: "text-blue-400" },
  { label: "Idiomas", value: 4, icon: Globe, color: "from-purple-500 to-pink-500", iconColor: "text-purple-400" },
  { label: "Uptime %", value: 99, icon: Zap, color: "from-yellow-500 to-orange-500", iconColor: "text-yellow-400" },
];

function Counter({ value }: { value: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      const duration = 2000;
      const incrementTime = duration / end;
      
      const timer = setInterval(() => {
        start += 1;
        setCount(start);
        if (start >= end) clearInterval(timer);
      }, incrementTime);
      
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return <span ref={ref}>{count}</span>;
}

export function Stats() {
  return (
    <section id="stats" className="py-20 bg-background relative z-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2, duration: 0.5 }}
              viewport={{ once: true }}
              className="group relative"
            >
              {/* Background glow effect */}
              <div className={`absolute inset-0 bg-gradient-to-r ${stat.color} rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300`}></div>
              
              <motion.div
                className="glass-panel p-8 rounded-2xl text-center relative z-10 border border-white/10 hover:border-white/20 transition-all"
                whileHover={{ y: -8 }}
                transition={{ duration: 0.3 }}
              >
                {/* Icon container with gradient background */}
                <motion.div 
                  className={`w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${stat.color} p-4 flex items-center justify-center shadow-lg`}
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 3, repeat: Infinity }}
                  whileHover={{ scale: 1.15 }}
                >
                  <motion.div
                    animate={{ rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 4, repeat: Infinity }}
                  >
                    <stat.icon className="w-10 h-10 text-white drop-shadow-lg" strokeWidth={1.5} />
                  </motion.div>
                </motion.div>

                {/* Value */}
                <div className="text-5xl font-heading text-transparent bg-clip-text bg-gradient-to-r from-chart-1 to-orange-500 mb-3">
                  <Counter value={stat.value} />
                  {stat.label.includes("%") && "%"}
                </div>

                {/* Label */}
                <div className="text-muted-foreground uppercase tracking-widest font-medium text-sm">{stat.label.replace(" %", "")}</div>

                {/* Decorative line */}
                <motion.div
                  className={`h-1 bg-gradient-to-r ${stat.color} rounded-full mt-4 mx-auto`}
                  initial={{ width: 0 }}
                  whileInView={{ width: "60%" }}
                  transition={{ delay: index * 0.2 + 0.3, duration: 0.6 }}
                  viewport={{ once: true }}
                ></motion.div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
