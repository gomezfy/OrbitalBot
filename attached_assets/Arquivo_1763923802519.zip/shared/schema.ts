import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, real, jsonb, unique } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ===================================
// WEBSITE TABLES (Admin/Login)
// ===================================

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const serverStats = pgTable("server_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tokensCirculating: integer("tokens_circulating").notNull().default(0),
  goldMined: real("gold_mined").notNull().default(0),
  activeGuilds: integer("active_guilds").notNull().default(0),
  activeBounties: integer("active_bounties").notNull().default(0),
  totalMembers: integer("total_members").notNull().default(0),
  commandsToday: integer("commands_today").notNull().default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertServerStatsSchema = createInsertSchema(serverStats).omit({
  id: true,
  updatedAt: true,
});
export type InsertServerStats = z.infer<typeof insertServerStatsSchema>;
export type ServerStats = typeof serverStats.$inferSelect;

export const serverSettings = pgTable("server_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dailyRewardsEnabled: boolean("daily_rewards_enabled").notNull().default(true),
  xpSystemEnabled: boolean("xp_system_enabled").notNull().default(true),
  territoriesEnabled: boolean("territories_enabled").notNull().default(true),
  autoWantedEnabled: boolean("auto_wanted_enabled").notNull().default(false),
  dailyRewardTime: text("daily_reward_time").notNull().default("21:00"),
  welcomeMessageEnabled: boolean("welcome_message_enabled").notNull().default(true),
  antiRaidEnabled: boolean("anti_raid_enabled").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertServerSettingsSchema = createInsertSchema(serverSettings).omit({
  id: true,
  updatedAt: true,
});
export type InsertServerSettings = z.infer<typeof insertServerSettingsSchema>;
export type ServerSettings = typeof serverSettings.$inferSelect;

export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: text("date").notNull(),
  economicActivity: integer("economic_activity").notNull().default(0),
  commandsRun: integer("commands_run").notNull().default(0),
  activeUsers: integer("active_users").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

export const guilds = pgTable("guilds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  leaderId: text("leader_id").notNull(),
  memberCount: integer("member_count").notNull().default(0),
  territory: text("territory"),
  totalWealth: integer("total_wealth").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertGuildSchema = createInsertSchema(guilds).omit({
  id: true,
  createdAt: true,
});
export type InsertGuild = z.infer<typeof insertGuildSchema>;
export type Guild = typeof guilds.$inferSelect;

// ===================================
// DISCORD BOT TABLES
// ===================================

export const discordUsers = pgTable('discord_users', {
  userId: text('user_id').primaryKey(),
  username: text('username').notNull(),
  
  gold: integer('gold').notNull().default(0),
  silver: integer('silver').notNull().default(0),
  saloonTokens: integer('saloon_tokens').notNull().default(0),
  bank: integer('bank').notNull().default(0),
  rexBucks: integer('rex_bucks').notNull().default(0),
  
  level: integer('level').notNull().default(1),
  xp: integer('xp').notNull().default(0),
  lastMessage: timestamp('last_message'),
  
  lastClaimDaily: timestamp('last_claim_daily'),
  dailyStreak: integer('daily_streak').notNull().default(0),
  
  customBackground: text('custom_background'),
  isVip: boolean('is_vip').notNull().default(false),
  badges: jsonb('badges').notNull().default([]),
  
  gamesPlayed: integer('games_played').notNull().default(0),
  bountiesCaptured: integer('bounties_captured').notNull().default(0),
  miningSessions: integer('mining_sessions').notNull().default(0),
  totalEarnings: integer('total_earnings').notNull().default(0),
  totalSpent: integer('total_spent').notNull().default(0),
  
  language: text('language').notNull().default('pt-BR'),
  showStats: boolean('show_stats').notNull().default(true),
  privateProfile: boolean('private_profile').notNull().default(false),
  
  backpackCapacity: integer('backpack_capacity').notNull().default(100),
  lastMiningTime: timestamp('last_mining_time'),
  totalMined: integer('total_mined').notNull().default(0),
  
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const discordInventoryItems = pgTable('discord_inventory_items', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  itemId: text('item_id').notNull(),
  name: text('name').notNull(),
  quantity: integer('quantity').notNull().default(1),
  weight: real('weight').notNull(),
  value: integer('value').notNull(),
  type: text('type').notNull(),
  durability: integer('durability'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  userItemUnique: unique().on(table.userId, table.itemId),
}));

export const discordBounties = pgTable('discord_bounties', {
  id: text('id').primaryKey(),
  targetId: text('target_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  issuerId: text('issuer_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  amount: integer('amount').notNull(),
  reason: text('reason').notNull(),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
  active: boolean('active').notNull().default(true),
});

export const discordActiveMining = pgTable('discord_active_mining', {
  userId: text('user_id').primaryKey().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  type: text('type').notNull(),
  startTime: timestamp('start_time').notNull(),
  endTime: timestamp('end_time').notNull(),
  claimed: boolean('claimed').notNull().default(false),
  goldAmount: integer('gold_amount').notNull(),
  partnerId: text('partner_id'),
  boosted: boolean('boosted').notNull().default(false),
  pickaxeBonus: boolean('pickaxe_bonus').notNull().default(false),
  notified: boolean('notified').notNull().default(false),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

export const discordTerritories = pgTable('discord_territories', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  ownerId: text('owner_id').references(() => discordUsers.userId, { onDelete: 'set null' }),
  controlledGuildId: text('controlled_guild_id'),
  income: integer('income').notNull().default(0),
  defenseLevel: integer('defense_level').notNull().default(1),
  lastIncomeTime: timestamp('last_income_time').notNull().defaultNow(),
});

export const discordPunishments = pgTable('discord_punishments', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  reason: text('reason').notNull(),
  startTime: timestamp('start_time').notNull(),
  duration: integer('duration').notNull(),
  active: boolean('active').notNull().default(true),
});

export const discordPlayerGuilds = pgTable('discord_player_guilds', {
  id: text('id').primaryKey(),
  name: text('name').notNull().unique(),
  description: text('description').notNull(),
  leaderId: text('leader_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  level: integer('level').notNull().default(1),
  xp: integer('xp').notNull().default(0),
  maxMembers: integer('max_members').notNull().default(10),
  isPublic: boolean('is_public').notNull().default(true),
  requireApproval: boolean('require_approval').notNull().default(false),
});

export const discordGuildMembers = pgTable('discord_guild_members', {
  id: text('id').primaryKey(),
  guildId: text('guild_id').notNull().references(() => discordPlayerGuilds.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  joinedAt: timestamp('joined_at').notNull().defaultNow(),
  role: text('role').notNull().default('member'),
});

export const discordGuildJoinRequests = pgTable('discord_guild_join_requests', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  guildId: text('guild_id').notNull().references(() => discordPlayerGuilds.id, { onDelete: 'cascade' }),
  requestedAt: timestamp('requested_at').notNull().defaultNow(),
  status: text('status').notNull().default('pending'),
});

export const discordLogs = pgTable('discord_logs', {
  id: text('id').primaryKey(),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
  type: text('type').notNull(),
  guildId: text('guild_id').notNull(),
  userId: text('user_id'),
  details: jsonb('details').notNull(),
});

export const discordRexBuckTransactions = pgTable('discord_rex_buck_transactions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => discordUsers.userId, { onDelete: 'cascade' }),
  amount: integer('amount').notNull(),
  type: text('type').notNull(),
  redemptionCode: text('redemption_code'),
  balanceBefore: integer('balance_before').notNull(),
  balanceAfter: integer('balance_after').notNull(),
  metadata: jsonb('metadata'),
  timestamp: timestamp('timestamp').notNull().defaultNow(),
});

export const discordWelcomeSettings = pgTable('discord_welcome_settings', {
  guildId: text('guild_id').primaryKey(),
  channelId: text('channel_id'),
  message: text('message'),
  enabled: boolean('enabled').notNull().default(false),
});

export const discordRedemptionCodes = pgTable('discord_redemption_codes', {
  code: text('code').primaryKey(),
  productId: text('product_id').notNull(),
  productName: text('product_name').notNull(),
  tokens: integer('tokens').notNull().default(0),
  coins: integer('coins').notNull().default(0),
  rexBucks: integer('rex_bucks').notNull().default(0),
  vip: boolean('vip').notNull().default(false),
  background: boolean('background').notNull().default(false),
  backpack: integer('backpack'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  createdBy: text('created_by').notNull(),
  redeemed: boolean('redeemed').notNull().default(false),
  redeemedBy: text('redeemed_by'),
  redeemedAt: timestamp('redeemed_at'),
});

export const discordRexBuckPackages = pgTable('discord_rex_buck_packages', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description').notNull(),
  amountRexBucks: integer('amount_rexbucks').notNull(),
  bonusRexBucks: integer('bonus_rexbucks').notNull().default(0),
  priceCents: integer('price_cents').notNull(),
  currency: text('currency').notNull().default('BRL'),
  active: boolean('active').notNull().default(true),
  displayOrder: integer('display_order').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const discordWarehouse = pgTable('discord_warehouse', {
  id: text('id').primaryKey().default('main'),
  stock: jsonb('stock').notNull().default({}),
  treasury: real('treasury').notNull().default(0),
  prices: jsonb('prices').notNull().default({}),
  statistics: jsonb('statistics').notNull().default({}),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Discord Server Configuration (per guild settings)
export const discordGuildConfig = pgTable('discord_guild_config', {
  guildId: text('guild_id').primaryKey(),
  guildName: text('guild_name').notNull(),
  language: text('language').notNull().default('pt-BR'),
  prefix: text('prefix').notNull().default('/'),
  
  // Logging
  logChannelId: text('log_channel_id'),
  loggingEnabled: boolean('logging_enabled').notNull().default(false),
  
  // Welcome/Leave
  welcomeChannelId: text('welcome_channel_id'),
  welcomeMessage: text('welcome_message'),
  welcomeEnabled: boolean('welcome_enabled').notNull().default(false),
  
  // Auto moderation
  autoModEnabled: boolean('auto_mod_enabled').notNull().default(false),
  antiSpamEnabled: boolean('anti_spam_enabled').notNull().default(false),
  antiRaidEnabled: boolean('anti_raid_enabled').notNull().default(false),
  
  // Systems enabled/disabled
  economyEnabled: boolean('economy_enabled').notNull().default(true),
  levelsEnabled: boolean('levels_enabled').notNull().default(true),
  bountiesEnabled: boolean('bounties_enabled').notNull().default(true),
  
  // Announcements
  announcementChannelId: text('announcement_channel_id'),
  
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

export const discordGuildAdmins = pgTable('discord_guild_admins', {
  id: text('id').primaryKey(),
  guildId: text('guild_id').notNull().references(() => discordGuildConfig.guildId, { onDelete: 'cascade' }),
  userId: text('user_id').notNull(),
  username: text('username').notNull(),
  addedAt: timestamp('added_at').notNull().defaultNow(),
}, (table) => ({
  guildUserUnique: unique().on(table.guildId, table.userId),
}));

// Export types
export type DiscordUser = typeof discordUsers.$inferSelect;
export type InsertDiscordUser = typeof discordUsers.$inferInsert;
export type DiscordInventoryItem = typeof discordInventoryItems.$inferSelect;
export type InsertDiscordInventoryItem = typeof discordInventoryItems.$inferInsert;
export type DiscordBounty = typeof discordBounties.$inferSelect;
export type InsertDiscordBounty = typeof discordBounties.$inferInsert;
export type DiscordActiveMining = typeof discordActiveMining.$inferSelect;
export type InsertDiscordActiveMining = typeof discordActiveMining.$inferInsert;
export type DiscordTerritory = typeof discordTerritories.$inferSelect;
export type InsertDiscordTerritory = typeof discordTerritories.$inferInsert;
export type DiscordPunishment = typeof discordPunishments.$inferSelect;
export type InsertDiscordPunishment = typeof discordPunishments.$inferInsert;
export type DiscordPlayerGuild = typeof discordPlayerGuilds.$inferSelect;
export type InsertDiscordPlayerGuild = typeof discordPlayerGuilds.$inferInsert;
export type DiscordGuildMember = typeof discordGuildMembers.$inferSelect;
export type InsertDiscordGuildMember = typeof discordGuildMembers.$inferInsert;
export type DiscordWelcomeSetting = typeof discordWelcomeSettings.$inferSelect;
export type InsertDiscordWelcomeSetting = typeof discordWelcomeSettings.$inferInsert;
export type DiscordRexBuckTransaction = typeof discordRexBuckTransactions.$inferSelect;
export type InsertDiscordRexBuckTransaction = typeof discordRexBuckTransactions.$inferInsert;
export type DiscordRedemptionCode = typeof discordRedemptionCodes.$inferSelect;
export type InsertDiscordRedemptionCode = typeof discordRedemptionCodes.$inferInsert;
export type DiscordWarehouse = typeof discordWarehouse.$inferSelect;
export type InsertDiscordWarehouse = typeof discordWarehouse.$inferInsert;
export type DiscordGuildConfig = typeof discordGuildConfig.$inferSelect;
export type InsertDiscordGuildConfig = typeof discordGuildConfig.$inferInsert;
export type DiscordGuildAdmin = typeof discordGuildAdmins.$inferSelect;
export type InsertDiscordGuildAdmin = typeof discordGuildAdmins.$inferInsert;
